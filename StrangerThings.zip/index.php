<?php
// ---------------------------------------------
// Parcial 1 - Programación Web II
// Tema: Stranger Things
// ---------------------------------------------

function h($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }

// 1) Array con 8 personajes
$personajes = [
  [
    'nombre' => 'Eleven',
    'categoria' => 'Protagonista, Niña especial, Héroe',
    'descripcion' => 'Joven con habilidades psíquicas que lucha contra las fuerzas del Upside Down. Criada en un laboratorio secreto, desarrolla poderes únicos y un fuerte lazo con sus amigos.',
    'imagen' => 'img/Eleven.jpg'
  ],
  [
    'nombre' => 'Mike Wheeler',
    'categoria' => 'Líder, Amigo fiel',
    'descripcion' => 'El estratega del grupo, siempre intenta mantener unidos a sus amigos. Soñador y valiente, dispuesto a arriesgarse por quienes quiere.',
    'imagen' => 'img/MikeWheeler.jpg'
  ],
  [
    'nombre' => 'Dustin Henderson',
    'categoria' => 'Ingenioso, Cómico, Inventor',
    'descripcion' => 'Fanático de la ciencia, la tecnología y los experimentos caseros. Su humor y creatividad suelen salvar al grupo en situaciones difíciles.',
    'imagen' => 'img/DustinHenderson.jpg'
  ],
  [
    'nombre' => 'Lucas Sinclair',
    'categoria' => 'Pragmático, Guerrero',
    'descripcion' => 'Más desconfiado que el resto, pero siempre listo para la acción. Aporta una visión práctica en medio de los planes descabellados del grupo.',
    'imagen' => 'img/LucasSinclair.jpg'
  ],
  [
    'nombre' => 'Will Byers',
    'categoria' => 'Víctima del Upside Down, Soñador',
    'descripcion' => 'Su conexión con el Upside Down lo convierte en una pieza clave. Tímido y sensible, pero con gran fortaleza interior.',
    'imagen' => 'img/WillByers.jpg'
  ],
  [
    'nombre' => 'Jim Hopper',
    'categoria' => 'Adulto, Protector, Autoridad',
    'descripcion' => 'El jefe de policía que asume el rol de padre para Eleven. Duro por fuera, pero con un gran corazón y sentido de justicia.',
    'imagen' => 'img/JimHopper.jpg'
  ],
  [
    'nombre' => 'Joyce Byers',
    'categoria' => 'Madre coraje, Protectora',
    'descripcion' => 'Dispuesta a enfrentarse a todo por rescatar a sus hijos. Valiente y perseverante, nunca baja los brazos ante lo imposible.',
    'imagen' => 'img/JoyceByers.jpg'
  ],
  [
    'nombre' => 'Vecna',
    'categoria' => 'Villano, Antagonista, Oscuro',
    'descripcion' => 'Poderoso ser del Upside Down con un pasado ligado a Eleven. Maestro del terror psicológico y la manipulación.',
    'imagen' => 'img/Vecna.jpg'
  ]
];

// 2) Parámetros GET
$q = $_GET['q'] ?? '';
$categoria = $_GET['categoria'] ?? '';
$tema = (isset($_GET['tema']) && in_array($_GET['tema'], ['claro','oscuro'])) ? $_GET['tema'] : 'oscuro';

// 3) Filtrar lista
$listaFiltrada = array_filter($personajes, function($p) use ($q, $categoria) {
  $ok = true;
  if ($q !== '') $ok = $ok && stripos($p['nombre'], $q) !== false;
  if ($categoria !== '') $ok = $ok && strcasecmp($p['categoria'], $categoria) === 0;
  return $ok;
});

// 4) POST para sugerencias
$errores = [];
$sugerenciaOk = false;
$preview = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $s_nombre = trim($_POST['s_nombre'] ?? '');
  $s_categoria = trim($_POST['s_categoria'] ?? '');
  $s_descripcion = trim($_POST['s_descripcion'] ?? '');
  $s_imagen = trim($_POST['s_imagen'] ?? '');

  if ($s_nombre === '') $errores[] = 'El nombre no puede estar vacío.';
  if ($s_categoria === '') $errores[] = 'La categoría no puede estar vacía.';
  if ($s_descripcion === '') $errores[] = 'La descripción no puede estar vacía.';
  if ($s_imagen === '') $s_imagen = 'https://via.placeholder.com/400x250?text=' . rawurlencode($s_nombre);

  if (empty($errores)) {
    $sugerenciaOk = true;
    $preview = [
      'nombre' => $s_nombre,
      'categoria' => $s_categoria,
      'descripcion' => $s_descripcion,
      'imagen' => $s_imagen
    ];
  }
}

// 5) Categorías únicas
$categorias = array_unique(array_map(fn($p)=>$p['categoria'], $personajes));
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Stranger Things</title>
  <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="<?= h($tema === 'claro' ? 'tema-claro' : 'tema-oscuro') ?>">
  <div class="container">
    <h1>Stranger Things - Personajes</h1>

    <!-- Formulario GET -->
    <form class="form-panel" method="GET">
      <input type="text" name="q" placeholder="Buscar por nombre..." value="<?= h($q) ?>">
      <select name="categoria">
        <option value="">Todas</option>
        <?php foreach ($categorias as $cat): ?>
          <option value="<?=h($cat)?>" <?= $categoria===$cat?'selected':''?>><?=h($cat)?></option>
        <?php endforeach; ?>
      </select>
      <select name="tema">
        <option value="oscuro" <?=$tema==='oscuro'?'selected':''?>>Oscuro</option>
        <option value="claro"  <?=$tema==='claro'?'selected':''?>>Claro</option>
      </select>
      <button type="submit">Filtrar</button>
    </form>

    <!-- Tarjetas -->
    <div class="cards">
      <?php if (empty($listaFiltrada)): ?>
        <p>No se encontraron personajes.</p>
      <?php else: ?>
        <?php foreach ($listaFiltrada as $p): ?>
          <article class="card">
            <img src="<?=h($p['imagen'])?>" alt="<?=h($p['nombre'])?>">
            <div class="content">
              <h3><?=h($p['nombre'])?></h3>
              <span class="chip"><?=h($p['categoria'])?></span>
              <p class="desc"><?=h($p['descripcion'])?></p>
            </div>
          </article>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <hr>

<h2>Sugerir nuevo personaje</h2>

<?php if (!empty($errores)): ?>
  <div class="msg-error"><?php foreach ($errores as $e): ?><p><?=h($e)?></p><?php endforeach; ?></div>
<?php elseif ($sugerenciaOk): ?>
  <div class="msg-ok">✔ Sugerencia recibida</div>
<?php endif; ?>

<form class="form-suggest" method="POST" novalidate>
  <div class="field">
    <label for="s_nombre">Nombre</label>
    <input id="s_nombre" type="text" name="s_nombre" placeholder="Ej: Max Mayfield" required>
  </div>

  <div class="field">
    <label for="s_categoria">Categoría</label>
    <input id="s_categoria" type="text" name="s_categoria" placeholder="Ej: Protagonista / Villano" required>
  </div>

  <div class="field field-textarea">
    <label for="s_descripcion">Descripción</label>
    <textarea id="s_descripcion" name="s_descripcion" placeholder="Breve descripción del personaje" required></textarea>
  </div>

  <div class="field">
    <label for="s_imagen">URL de imagen (opcional)</label>
    <input id="s_imagen" type="text" name="s_imagen" placeholder="https://...">
  </div>

  <button type="submit" class="btn-primary">Enviar</button>
</form>

<?php if ($preview): ?>
  <h3>Previsualización:</h3>
  <div class="cards">
    <article class="card">
      <img src="<?=h($preview['imagen'])?>" alt="<?=h($preview['nombre'])?>">
      <div class="content">
        <h3><?=h($preview['nombre'])?></h3>
        <span class="chip"><?=h($preview['categoria'])?></span>
        <p class="desc"><?=h($preview['descripcion'])?></p>
      </div>
    </article>
  </div>
<?php endif; ?>


